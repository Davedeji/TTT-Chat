import "./index.css"

const GameResults = () => {
    return (
        <div>
            Results
        </div>
    )
}

export default GameResults 