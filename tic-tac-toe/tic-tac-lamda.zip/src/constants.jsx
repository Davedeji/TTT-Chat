export const CIRCLE = "CIRCLE"
export const CROSS = "CROSS"
export const EMPTY = "EMPTY"